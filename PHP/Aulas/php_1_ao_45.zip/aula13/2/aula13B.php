<?php

	$vnome=$_POST["f_nome"];
	$vsenha=$_POST["f_senha"];
	
	echo "Nome: ".$vnome."<br/>Senha: ".$vsenha."<br/>";

?>