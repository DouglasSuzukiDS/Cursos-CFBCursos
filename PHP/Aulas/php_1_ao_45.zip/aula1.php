<?php

	//Comentário simples em PHP
	/*
		sjgnhgj
		elkgjnwgk
		klegnjwegk
		ekgjg
		kgj
	*/
	
	echo "<font color=#ff0000>Primeira linha em PHP</font><br/>";
	echo "Curso de PHP";

?>

<html>
<head>
	<title>Aula 1 de PHP</title>
</head>
<body>

	<p>Texto escrito em HTML</p>
	<?php
		echo "Texto escrito em PHP";
	?>

</body>
</html>