<?php

$vtexto=$_GET["tx"];
$vnome=$_GET["no"];
$vcanal=$_GET["cn"];

echo $vtexto."<br/>";
echo $vnome."<br/>";
echo $vcanal."<br/>";

?>

<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<title>Página 1</title>
</head>
<body>

</body>
</html>