<?php

include "data.inc";
echo "<br/>";
include "menu.inc";

?>

<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<title>Aula 16 de PHP - Include</title>
</head>
<body>

</body>
</html>