<?php

	include "conexao.inc";
	
	mysqli_close($con);

?>

<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<title>Aula 28 de PHP - Conexão com banco de dados</title>
</head>
<body>


</body>
</html>