<?php

	$num1=10;
	$num2=5;
	
	//Aritméticos (Matemáticos)
	$res = $num1 + $num2;
	echo "Soma de $num1 com $num2 = $res<br/>";
	$res = $num1 - $num2;
	echo "A subtração de $num1 com $num2 = $res<br/>";
	$res = $num1 / $num2;
	echo "Divisão de $num1 por $num2 = $res<br/>";
	$res = $num1 * $num2;
	echo "Multiplicação de $num1 com $num2 = $res<br/>";
	
	$res = $num1 % $num2;
	echo "Resto da divisão de $num1 com $num2 = $res<hr/>";
	
	$num1++; //$num1 = $num1 + 1;            -           $num1+=1;
	echo "Novo valor de num1: $num1<br/>";
	
	$num2+=10; //$num2 = $num2 + 10;    -    $num2*=10;    -    $num2/=10;     -      $num2-=10;
	echo "Novo valor de num2: $num2<br/>";
	
	$res = $num1 == $num2;
	echo "Num1 igual Num2 = $res<br/>";
	
	
	
	


?>

<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<title>Aula 3 de PHP - Operações com variáveis</title>
</head>
<body>

</body>
</html>